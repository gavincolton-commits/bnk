*************************************************************
**************PRODUCT OF DIGITALWEBPLUS.COM******************
*************************************************************

SCRIPT NAME: PRIME CARGO SCRIPT

(Read to the end)

**DISCLAIMER**

Using our script you will be 100% responsible for your web security. We have done our best to make sure this script is highly secured, but we do not give any guarantee. And as well we will not be linked to any loss or damage you may encounter while using this script.

We do not guarantee that our scripts are not hackable, if you are using our script you will be responsible for your cybersecurity.

Our scripts are built for educational and research purpose, we do not support using it for illegal or illegitimate purpose, using it is fully at your own risk.

**SECURITY**

On your cPanel/server it is advisable to activate 2FA for a better security. Once a hackers is able to hack into your server they will have full access to every script and database on it.

The most sensitive thing on most scripts are the wallet addresses and payment gateways (if any). We strongly advise you create a user account where you will monitor the wallet addresses and other thing your site users are seeing on their end. This will help you easily detect most abnormalities that may occur on your site.

**BACKUP**

Anytime you want to make a edit on the code always remember to take a full backup of the file and database, so you will have something to fall back on if you encounter issues.

Always use a hosting package that provides automated backup of your file on daily or/and weekly bases as the case may be. This will help you to always restore your site to a previous state if need be.

**DOMAIN NAME**

While purchasing a domain, thats if you choose to take your site online, it is always advisable to buy a domain name that is not similar to an existing name on the internet, to prevent your to be seen as deceptive.


***SCRIPT CREDENTIALS***

Note: if you do an auto installation, the first registered users is automatically the admin.

But if you choose to import th SQL file the login details below will be used.

Admin Username: admin@yourdomain.com

Admin Password: admin123 (make sure you change admin password)

Admin Login URL: ../admin

Customers Login URL: ../dashboard

Customers Registration URL: ../dashboard/signup

Database SQL File Location: ../uss-modules/primecargo.sql

Configuration File Location: ../uss-core/conn.php

Languages: HTML, PHP, MYSQL, JavaScript and CSS

/
/


***SERVER REQUIREMENT***

-Shared hosting or VPS
-PHP 7.4
-Must support MySQL
(((THIS SCRIPT HAS BEEN TESTED AND ITS WORKING PERFECTLY ON XAMPP LOCAL SERVER AND STANDARD LIVE SERVER)))

/
/

***How to install this script***

-Download the file

-Unzip the file

-Unload the file to a live server or local server

-Create a database

-Create a database user and set a strong password for it

-Add the database user you created to the database you just created, and grant all privileges to the user (for those on live server).

-Edit the configuration file to your server information (edit database name, database user and database password, it will be found in /uss-core/conn.php)

-Then lunch the site the SQL will install authomatically, in case if this didnt happen then you can install it manually

-For manual installation go to  phpMyAdmin and import your script database file to your database (the file will be found in the ../uss-modules/primecargo.sql in the file you unzipped)


-Create webmail, (the email the will be responsible for all mails)

-Use your web browser to locate the site.

-Login to your admin, go to settings, and update the information there.

