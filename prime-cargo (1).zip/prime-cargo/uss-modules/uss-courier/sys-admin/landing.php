<?php

defined( 'COURIER_DIR' ) OR DIE;

Events::addListener('uadmin:pages/index', function() {

	if( !Uss::$global['user'] ) return;
	
	$stats = self::stats();
	
	$icons = array(
		"users" => "bi bi-people",
		"staffs" => "bi bi-universal-access",
		"offices" => "bi bi-building",
		"gateways" => "bi bi-stripe",
		"payments" => "bi bi-coin",
		"shipments" => "bi bi-truck"
	);
	
?>

	<div class='container-fluid'>
		<div class='row'>
		<?php 
			foreach( $stats as $key => $value ):
		?>
			<div class='col-lg-4 mb-3'>
				<div class='card'>
					<div class='card-body d-flex'>
						<div class='display-6 me-3'>
							<i class='<?php echo $icons[$key]; ?>'></i>
						</div>
						<div class='text-capitalize'>
							<h5 class='display-6'><?php echo $key; ?></h5>
							<h1 class='display-6'><?php echo $value; ?></h1>
						</div>
					</div>
				</div>
			</div>
		<?php endforeach; ?>
		</div>
	</div>
	
<?php });