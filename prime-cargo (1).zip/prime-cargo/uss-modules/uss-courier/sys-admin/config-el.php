<?php 
	Events::addListener('uadmin:pages/settings/general@form', function() {
?>
<div class='mb-3 mb-lg-4 row'>
	<label class='form-label col-lg-3'>Currency</label>
	<div class='col-lg-9'>
		<input type='text' name='site[currency]' class='form-control' rows='8' value='<?php echo Uss::$global['options']->get('site:currency'); ?>'>
	</div>
</div>
<?php }, EVENT_ID . 'field_401' );

