<?php 

defined( 'COURIER_DIR' ) OR DIE;

$newFocus = $officeFocus . "/new";

// Create Menu

$newMenu = $officeMenu->add('new', array(
	"label" => "Add new",
	"href" => self::href( $newFocus )
));

// Create Content;

Uss::route( $newFocus . "(?:/(\d+))?", function($match) use($newMenu) {
	
	$newMenu->setAttr('active', true);
	$newMenu->parentMenu->setAttr('active', true);
	
	if( Uss::$global['user'] ) require __DIR__ . "/POST.php";
	
	Udash::view(function() {
		require __DIR__ . '/new-view.php';
	});
	
}, NULL);

