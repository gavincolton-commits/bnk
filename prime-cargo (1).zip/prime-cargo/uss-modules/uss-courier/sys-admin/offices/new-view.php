<div class='container-fluid'>

	<h3> <i class='bi bi-building-add'></i> %{page.type} Office </h3>
	
	<hr/>
	
	<form method='POST' enctype='multipart/form-data'>
		<fieldset>
			
			%{response.message}
			
			<div class='row'>
				
				<div class='col-lg-7'>
					
					<legend class='fs-28px border-bottom mb-4'>Location</legend>
					
					<div class='mb-3'>
						<label class='form-label --required'> Branch Name </label>
						<input name='branch' class='form-control' value='%{office.branch}' required>
					</div>
					
					<div class='mb-3'>
						<label class='form-label --required'> Address </label>
						<textarea name='address' class='form-control' required>%{office.address}</textarea>
					</div>
					
					<div class='mb-3'>
						<label class='form-label --required'> State </label>
						<input name='state' class='form-control' value='%{office.state}' required>
					</div>
					
					<div class='mb-4'>
						<label class='form-label --required'> Countries </label>
						<select name='country' class='form-control' value='%{office.country}'>
							%{export.countries}
						</select>
					</div>
					
					<div class='mb-3'>
						<div class='form-check'>
							<label class='form-label-label' for='main'> Use As Main Office </label>
							<input type='hidden' name='_default' value='0'>
							<input type='checkbox' class='form-check-input' name='_default' value='1' id='main' %{office.main}>
						</div>
					</div>
					
				</div>
				
				<div class='col-lg-5'>
					
					<legend class='fs-28px border-bottom mb-4'>Contact</legend>
					
					<div class='mb-3'>
						<label class='form-label --required'> Email </label>
						<input type='text' name='email' class='form-control' value='%{office.email}' required>
					</div>
					
					<div class='mb-3'>
						<label class='form-label --required'> Phone </label>
						<input name='phone' class='form-control' value='%{office.phone}' required>
					</div>
					
					<div class='mb-3'>
						<label class='form-label --required'> Status </label>
						<select name='status' class='form-control' value='%{office.status}'>
							<option value='1'>Enabled</option>
							<option value='0'>Disabled</option>
						</select>
					</div>
					
				</div>
				
			</div>
			
			<hr>
			
			<button class='btn btn-success'>
				%{page.action} Office
			</button>
			
		</fieldset>
	</form>
	
</div>