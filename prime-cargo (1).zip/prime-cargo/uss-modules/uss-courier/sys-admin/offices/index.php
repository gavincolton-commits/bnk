<?php 

defined( 'COURIER_DIR' ) OR DIE;

/** Office Menu */

$officeMenu = Uss::$global['menu']->add('car', array(
	'label' => "Offices",
	'icon' => "<i class='bi bi-buildings'></i>"
));

/** Office Focus */

$officeFocus = self::$adminFocus . "/offices";

/** Office Management */

require __DIR__ . '/new.php';
require __DIR__ . '/list.php';