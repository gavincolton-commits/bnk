<?php 

defined( 'COURIER_DIR' ) OR DIE;

$editFocus = $paymentFocus . "/edit";

$GLOBALS['new-payment-url'] = self::href( self::$clientFocus . "/payment/new" );

Uss::route( $editFocus . "/(\d+)", function($match) use($historyMenu) {
	
	$historyMenu->setAttr('active', true);
	$historyMenu->parentMenu->setAttr('active', true);
	
	require __DIR__ . '/POST.php';
	
	Udash::view(function() use($editor) {
		
		if( !$editor->payment ) return Udash::empty_state( "No transaction was found" );
		else if( !$editor->order ) return Udash::empty_state( "The order of the transaction is missing" );
		
		require __DIR__ . "/edit-template.php";
		
	});
	
}, NULL);