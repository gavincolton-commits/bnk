<?php 

defined( 'COURIER_DIR' ) OR DIE;

/**
 * PAYMENT HISTORY MADE FOR ORDERS
 */

// Create a focus path

$paymentFocus = self::$adminFocus . "/payments";

/** Create Payment Menu */

$paymentMenu = Uss::$global['menu']->add('payments', array(
	"label" => "Payments",
	"icon" => "<i class='bi bi-wallet'></i>"
));


// Get payment pages

require __DIR__ . "/list.php";
require __DIR__ . "/edit.php";
