<?php 

defined( 'COURIER_DIR' ) OR DIE;

new class {
	
	public $tablename = DB_TABLE_PREFIX . "_variants";
	
	public function __construct() {
		
		$this->trash();
		
		if( $_SERVER['REQUEST_METHOD'] !== 'POST' ) return;
		
		$data = $_POST;
		array_walk($data, function(&$value, $key) {
			$value = Uss::$global['mysqli']->real_escape_string( $value );
		});
		
		!empty($_POST['id']) ? $this->update( $data ) : $this->insert( $data );
		
	}
	
	public function update( $data ) {
		
		$SQL = SQuery::update( $this->tablename, $data, "id = '{$data['id']}'" );
		
		$result = Uss::$global['mysqli']->query( $SQL );
		
		if( $result ) $this->msg("The variety was successfully updated", $result);
		else $this->msg("$this->The variety was not updated", $result);
		
	}
	
	public function insert( $data ) {
		
		try {
			
			if( empty($data['id']) ) unset($data['id']);

			$SQL = SQuery::insert( $this->tablename, $data );
			
			$result = Uss::$global['mysqli']->query( $SQL );

		} catch(Exception $e) {

			$result = false;

		}
		
		if( $result ) $this->msg( "The variety was successfully added", $result );
		else $this->msg( "The variety was not added", $result );
		
	}
	
	private function msg( string $message, bool $val ) {
		
		$icon = $val ? "<i class='bi bi-check-circle me-2'></i>" : "<i class='bi bi-exclamation-triangle me-2'></i>";
		
		Uss::console( '@alert', $icon . $message );
		
	}
	
	private function trash() {
		
		if( !isset($_GET['trash']) || !is_numeric($_GET['trash']) ) return;
		
		$id = Uss::$global['mysqli']->real_escape_string($_GET['trash']);
		
		$SQL = "DELETE FROM {$this->tablename} WHERE id = {$id}";
		
		Uss::$global['mysqli']->query( $SQL );
		
	}
	
};