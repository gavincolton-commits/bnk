<?php 

defined( 'COURIER_DIR' ) OR DIE;

$varFocus = self::$adminFocus . "/variety";

/** Variation Menu */

$varMenu = Uss::$global['menu']->add('var', array(
	"label" => "variety",
	"icon" => "<i class='bi bi-tags'></i>",
	"href" => self::href( $varFocus )
));

/** View */

Uss::route( $varFocus, function() use($varMenu) {
	
	$varMenu->setAttr('active', true);
	
	if( Uss::$global['user'] ) {
		
		Events::addListener('@body:after', function() {
			echo "\t<script src='" . Core::url( __DIR__ . '/script.js' ) . "'></script>\n";
		}, get_called_class());
		
		require __DIR__ . '/POST.php';
		
	};
	
	Udash::view(function() {
		require __DIR__ . '/var-view.php';
	});
	
}, NULL);