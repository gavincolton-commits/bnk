"use strict";

$(function() {

	new class {
		
		constructor() {
			
			let self = this;
			
			$('[data-var-name][data-var-id]').click(function() {
				
				let varForm = $(".editor-container" ).html();
				
				varForm = varForm.replace('@id', this.dataset.varId);
				varForm = varForm.replace('@value', this.dataset.varName);
				
				bootbox.confirm(varForm, function(done) {
					
					if( !done ) return;
					
					let form = $(this).find('form');
					let name = form.find('input[name="name"]').val().trim();
					
					if( name == '' ) return toastr.warning('Variery cannot be empty');
					
					form.trigger('submit');
					
				});
				
			});
			
		}
		
	}

});