"use strict";

$(function() {

	new class {
		
		constructor() {
			this.#dataSeek();
		}
		
		#dataSeek() {
			let time;
			$("input[data-seek]").on('input', function() {
				clearTimeout(time);
				let value  = this.value.trim();
				time = setTimeout(function() {
					console.log( value );
					$.ajax({
						method: 'POST',
						url: uss.ajax,
						data: { 
							email: value,
							route: 'cargo-ship-client',
							nonce: uss.Nonce
						},
						success: function(response) {
							console.log( response );
						}
					});
				}, 1700);
			});
		}
		
	};

});