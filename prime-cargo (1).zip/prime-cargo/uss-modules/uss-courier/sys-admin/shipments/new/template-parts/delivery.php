<div class="accordion mb-4" id="delivery">
	<div class="accordion-item">

		<h4 class="accordion-header" id="headingOne">
			<button class="accordion-button fw-bold shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#deliveryContainer" aria-expanded="true" aria-controls="deliveryContainer">
				<i class='bi bi-info-circle me-2'></i> Delivery
			</button>
		</h4>

		<div id="deliveryContainer" class="accordion-collapse collapse show" data-bs-parent="#delivery">
			<div class="accordion-body">

				<div class='row'>
                    
                    <div class='col-lg-6 mb-4'>
                        <h5>Origin</h5>
                        <div class='border rounded-2 p-4'>
                            <div class='mb-3'>
                                <label class='form-label --required'>Address</label>
                                <textarea class='form-control' required placeholder='' name='delivery[origin][address]'>%{delivery.origin.address}</textarea>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label --required'>City</label>
                                <input class='form-control' required placeholder='' name='delivery[origin][city]' value='%{delivery.origin.city}'>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label --required'>Country</label>
                                <select name='delivery[origin][country]' class='form-select' value='%{delivery.origin.country}' required>
                                    <?php $render->list( Udash::countries() ); ?>
                                </select>
                            </div>
                        </div>
					</div>
                    
					<div class='col-lg-6 mb-4'>
                        <h5>Destination</h5>
                        <div class='border rounded-2 p-4'>
                            <div class='mb-3'>
                                <label class='form-label --required'>Address</label>
                                <textarea class='form-control' required placeholder='' name='delivery[destination][address]'>%{delivery.destination.address}</textarea>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label --required'>City</label>
                                <input class='form-control' required placeholder='' name='delivery[destination][city]' value='%{delivery.destination.city}'>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label --required'>Country</label>
                                <select name='delivery[destination][country]' class='form-select' value='%{delivery.destination.country}' required>
                                    <?php $render->list( Udash::countries() ); ?>
                                </select>
                            </div>
                        </div>
					</div>

				</div> <!-- /.rows -->

			</div>
		</div>
	</div>
</div>