<div class='mb-4'>
    <a href='%{uri.shipment}/package/%{order.order_no}' class='btn btn-primary me-2'>
        <i class='bi bi-box-seam-fill me-1'></i> Packages
    </a>
    <a href='%{uri.shipment}/tracker/%{order.order_no}' class='btn btn-primary me-2'>
        <i class='bi bi-geo-alt-fill me-1'></i> History
    </a>
    <a href='%{uri.root}/tracker?id=%{order.order_no}' target='_blank' class='btn btn-outline-secondary me-2'>
        <i class='bi bi-eye me-1'></i> View Track
    </a>
</div>

<div class='card mb-4'>
    <div class='card-body'>
        <h5 class='text-center border-bottom fw-light pb-2'>Placement Detail</h5>
        <div class='table-responsive'>
            <table class='table table-striped text-capitalize'>
                <tbody>
                    <?php foreach( $render->orderInfo() as $key => $value ): ?>
                    <tr>
                        <th><?php echo $key; ?></th>
                        <td><?php echo $value; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>