<div class='mb-4'>
	<label class='form-label'>TRACK ID</label>
	<input type='text' readonly name='order[order_no]' value='%{order.order_no}' class='form-control form-control-lg' required>
</div>

<div class='mb-4'>
	<label class='form-label'>PLACEMENT NAME</label>
	<input type='text' name='order[name]' value='%{order.name}' class='form-control form-control-lg' required>
</div>

%{response.message}