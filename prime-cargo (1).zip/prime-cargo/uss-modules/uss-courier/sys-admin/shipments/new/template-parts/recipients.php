<div class="accordion mb-4" id="recipients">
	<div class="accordion-item">

		<h4 class="accordion-header" id="headingOne">
			<button class="accordion-button fw-bold shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#recipientContainer" aria-expanded="true" aria-controls="recipientContainer">
				<i class='bi bi-people me-2'></i> Recepients
			</button>
		</h4>

		<div id="recipientContainer" class="accordion-collapse collapse show" data-bs-parent="#recipients">
			<div class="accordion-body">

				<div class='row'>
					<div class='col-lg-6 mb-3'>
						<div class='card'>
							<h5 class='card-header'> Sender Detail </h5>
							<div class='card-body'>
								
								<div class='mb-3 position-relative'>
									<input type='email' class='form-control mb-1' name='sender[email]' placeholder='Sender&apos;s email' data-seek='sender' value='%{sender.email}' required>
								</div>
								
								<div class='%{detail.row}'>
									<label class='form-label %{detail.label.class} --required'>Name</label>
									<div class='%{detail.input.class}'>
										<input type='text' name='sender[name]' class='form-control' placeholder='Sender&apos;s name' value='%{sender.name}' required>
									</div>
								</div>
							
								<div class='%{detail.row}'>
									<label class='form-label %{detail.label.class} --required'>Phone</label>
									<div class='%{detail.input.class}'>
										<input type='text' name='sender[phone]' class='form-control' placeholder='Sender&apos;s phone' value='%{sender.phone}' required>
									</div>
								</div>
							
								<div class='%{detail.row}'>
									<label class='form-label %{detail.label.class} --required'>Address</label>
									<div class='%{detail.input.class}'>
										<textarea type='text' name='sender[address]' class='form-control' placeholder='Sender&apos;s address' required>%{sender.address}</textarea>
									</div>
								</div>
							
								<div class='%{detail.row}'>
									<label class='form-label %{detail.label.class} --required'>State</label>
									<div class='%{detail.input.class}'>
										<input type='text' name='sender[state]' class='form-control' placeholder='Sender&apos;s state' value='%{sender.state}' required>
									</div>
								</div>
							
								<div class='%{detail.row}'>
									<label class='form-label %{detail.label.class} --required'>Country</label>
									<div class='%{detail.input.class}'>
										<select name='sender[country]' class='form-select' value='%{sender.country}' required>
											<?php $render->list( Udash::countries() ); ?>
										</select>
									</div>
								</div>
								
							</div>
						</div>
					</div>
					<div class='col-lg-6'>
						<div class='card'>
							<h5 class='card-header'> Receiver Detail </h5>
							<div class='card-body'>
								
								<div class='mb-3 row'>
									<div class='col-lg-12'>
										<input type='email' name='receiver[email]' placeholder='Receiver&apos;s email' class='form-control' value='%{receiver.email}' data-seek='receiver'>
									</div>
								</div>
								
								<div class='%{detail.row}'>
									<label class='form-label %{detail.label.class} --required'>Name</label>
									<div class='%{detail.input.class}'>
										<input type='text' name='receiver[name]' class='form-control' placeholder='Receiver&apos;s name' value='%{receiver.name}'required>
									</div>
								</div>
							
								<div class='%{detail.row}'>
									<label class='form-label %{detail.label.class} --required'>Phone</label>
									<div class='%{detail.input.class}'>
										<input type='text' name='receiver[phone]' class='form-control' placeholder='Receiver&apos;s phone' value='%{receiver.phone}' required>
									</div>
								</div>
							
								<div class='%{detail.row}'>
									<label class='form-label %{detail.label.class} --required'>Address</label>
									<div class='%{detail.input.class}'>
										<textarea name='receiver[address]' class='form-control' placeholder='Receiver&apos;s address' required>%{receiver.address}</textarea>
									</div>
								</div>
							
								<div class='%{detail.row}'>
									<label class='form-label %{detail.label.class} --required'>State</label>
									<div class='%{detail.input.class}'>
										<input type='text' name='receiver[state]' class='form-control' placeholder='Receiver&apos;s state' value='%{receiver.state}' required>
									</div>
								</div>
							
								<div class='%{detail.row}'>
									<label class='form-label %{detail.label.class} --required'>Country</label>
									<div class='%{detail.input.class}'>
										<select name='receiver[country]' value='%{receiver.country}' class='form-select' required>
											<?php $render->list( Udash::countries() ); ?>
										</select>
									</div>
								</div>
								
							</div>
						</div>
					</div>
				</div>

			</div>
		</div> <!-- #recipientContainer -->

	</div>
</div>