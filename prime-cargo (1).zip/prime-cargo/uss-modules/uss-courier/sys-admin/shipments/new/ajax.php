<?php 

defined( 'COURIER_DIR' ) OR DIE;

Events::addListener('udash:ajax', function() {
	
	if( $_POST['route'] != 'cargo-ship-client' || !Uss::nonce( $_SESSION['uss_session_id'], $_POST['nonce'] ) ) return;
	
	$tablename = DB_TABLE_PREFIX . "_users";
	
	$email = Uss::$global['mysqli']->real_escape_string( $_POST['email'] );
	
	$SQL = "
		SELECT * FROM {$tablename}
		WHERE email LIKE '{$email}%'
	";
	
	$result = Uss::$global['mysqli']->query( $SQL );
	
	//var_dump( $result );
	
});