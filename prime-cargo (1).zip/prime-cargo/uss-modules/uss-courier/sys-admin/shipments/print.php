<?php

# Print Focus;

$printFocus = $shipmentFocus . "/print";

# Route;

Uss::route( $printFocus, function() use($orderMenu) {

    $orderMenu->setAttr('active', true);
	$orderMenu->parentMenu->setAttr('active', true);

    Udash::view(function() {

        $order = $_GET['order'] ?? null;

        if( empty($order) ) return Udash::empty_state();

        Courier::invoice( $_GET['order'] ?? '' );

    });

});