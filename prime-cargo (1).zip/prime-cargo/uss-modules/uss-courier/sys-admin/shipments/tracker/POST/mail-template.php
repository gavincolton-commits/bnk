 <div style="max-width: 600px; margin: 0 auto; padding: 20px;">

    <table style="width: 100%; border-collapse: collapse;">
        <tr>
            <td align="center">
                <img src="%{logo}" alt="Company Logo" style="max-height: 60px;">
            </td>
        </tr>
    </table>
    
    <h2 style="color: #333; margin-bottom: 20px;">Package Shipment Update</h2>

    <p style="color: #555; margin-bottom: 20px;">
        Dear %{sender_name},<br>
        We are pleased to inform you that your package has been shipped to a new location.
    </p>

    <table style="width: 100%; border-collapse: collapse; border: 1px solid #ddd; margin-bottom: 20px;">
        <tr style="background-color: #f9f9f9;">
            <th style="padding: 10px; border: 1px solid #ddd;">Tracking Number</th>
            <th style="padding: 10px; border: 1px solid #ddd;">Location</th>
            <th style="padding: 10px; border: 1px solid #ddd;">Region</th>
            <th style="padding: 10px; border: 1px solid #ddd;">Shipment Date</th>
        </tr>
        <tr>
            <td style="padding: 10px; border: 1px solid #ddd;">%{order_no}</td>
            <td style="padding: 10px; border: 1px solid #ddd;">%{local_area}</td>
            <td style="padding: 10px; border: 1px solid #ddd;">%{state}, %{country}</td>
            <td style="padding: 10px; border: 1px solid #ddd;">%{date}</td>
        </tr>
    </table>

    <p style="color: #555; margin-bottom: 20px;">
        For tracking your shipment, you can use the provided tracking number on our website or contact our customer support.
    </p>

    <p style="color: #555; margin-bottom: 20px;">
        If you have any questions or need further assistance, please don't hesitate to contact us.
    </p>
    
    <p style="color: #555;">
        Thank you for choosing %{company_name} for your shipping needs!
    </p>

    <p style="color: #555;">
        Best regards,<br>
        %{company_name}
    </p>

</div>