<?php 

defined( 'COURIER_DIR' ) OR DIE;

/**
 * This does not need a menu
 */
$trackerFocus = $shipmentFocus . "/tracker";

Uss::tag( 'uri.tracker', self::href( $trackerFocus ) );


/**
 * PAGES
 */
require __DIR__ . "/new.php";
require __DIR__ . "/list.php";

