<?php

defined( 'COURIER_DIR' ) OR DIE;

Uss::route( $packageFocus . "/([a-zA-Z0-9\-]+)", function($data) use($orderMenu) {
	
	$orderMenu->setAttr('active', true);
	$orderMenu->parentMenu->setAttr('active', true);
	
	Udash::view(function() {
		
		
		
	});
	
});

