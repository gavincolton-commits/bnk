<?php 

defined( 'COURIER_DIR' ) OR DIE;

$shipmentFocus = self::$adminFocus . "/shipping";

/**
 * Use URL across templates
 */
Uss::tag( 'uri.shipment', self::href( $shipmentFocus ) );

/**
 * Shipment Menu
 */
$shipmentMenu = Uss::$global['menu']->add('shipment', array(
	"label" => "Shippings",
	"icon" => "<i class='bi bi-truck'></i>"
));

/** 
 * Get shipping pages 
 */
require __DIR__ . '/placements.php';
require __DIR__ . '/print.php';
require __DIR__ . '/new/index.php';
require __DIR__ . '/tracker/index.php';
require __DIR__ . '/package/index.php';