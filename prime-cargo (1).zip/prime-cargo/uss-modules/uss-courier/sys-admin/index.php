<?php 

defined( 'COURIER_DIR' ) OR DIE;

require_once __DIR__ . "/config-el.php";

/**
 * Directories;
 */
$pages = array(
	"users",
    "shipments",
	"offices",
	"varieties",
	"gateways",
	"payments"
);

/**
 * Require Files
 */
foreach( $pages as $dirname ) require_once __DIR__  . "/{$dirname}/index.php";

/**
 *
 */
require_once __DIR__ . "/landing.php";
