<?php 

defined( 'COURIER_DIR' ) OR DIE;

$newFocus = $gatewayFocus . "/new";

// Create Menu

$newMenu = $gatewayMenu->add('new', array(
	"label" => "Add new",
	"href" => self::href( $newFocus )
));

/** Create View */

Uss::route( $newFocus . "(?:/(\w+))?", function($match) use($newMenu) {
	
	$newMenu->setAttr('active', true);
	$newMenu->parentMenu->setAttr('active', true);
	
	if( Uss::$global['user'] ) {
		
		Events::addListener('@body:after', function() {
			echo "\t<script src='" . Core::url( __DIR__ . '/script.js' ) . "'></script>\n";
		}, get_called_class());
		
		require __DIR__ . '/POST.php';
	
	};
	
	Udash::view(function() {
		require __DIR__ . '/new-view.php';
	});
	
}, NULL);