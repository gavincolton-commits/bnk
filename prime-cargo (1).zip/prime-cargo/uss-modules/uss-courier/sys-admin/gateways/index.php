<?php 

$gatewayFocus = self::$adminFocus . "/gateway";

/** Create Menu */

$gatewayMenu = Uss::$global['menu']->add('gateway', array(
	"label" => "Gateways",
	"icon" => "<i class='bi bi-credit-card'></i>"
));

/** Require Gateways Pages */

require __DIR__ . "/new.php";
require __DIR__ . "/list.php";