<?php 
/**
 * Courier Management System
 * 
 * @copyright 2023 (c) ucscode
 * @author ucscode <uche23mail@gmail.com>
 * @package uss.courier
 */
defined( 'ROOT_DIR' ) OR DIE;

# Check if dashboard module is loaded

define( 'COURIER_DIR', __DIR__ );

/**
 * Require The Courier Static Class
 */
require COURIER_DIR . '/Courier.php';

/**
 * Load all class content
 */
Courier::constructor();

