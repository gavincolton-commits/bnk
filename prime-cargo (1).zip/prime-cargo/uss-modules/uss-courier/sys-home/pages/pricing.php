    <!-- ======= Pricing Section ======= -->
    <section id="pricing" class="pricing">
      <div class="container" data-aos="fade-up">

        <div class="row gy-4">

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <div class="pricing-item">
              <h3>Plain</h3>
              <h4><sup>$</sup>0<span> / month</span></h4>
              <ul>
                <li><i class="bi bi-check"></i> Unlimited tracking</li>
                <li><i class="bi bi-check"></i> Pay for each shipment</li>
                <li><i class="bi bi-check"></i> User management dashboard</li>
                <li><i class="bi bi-check"></i> Free customer support</li>
              </ul>
              <a href="%{url.dashboard}">Sign In</a>
            </div>
          </div><!-- End Pricing Item -->

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <div class="pricing-item featured">
              <h3>Membership</h3>
              <h4><sup>$</sup>49<span> / month</span></h4>
              <ul>
                <li><i class="bi bi-check"></i> Unlimited tracking</li>
                <li><i class="bi bi-check"></i> No payment for delivery</li>
                <li><i class="bi bi-check"></i> User management dashboard</li>
                <li><i class="bi bi-check"></i> Free customer support</li>
              </ul>
              <a href="contact.html">Contact Support</a>
            </div>
          </div><!-- End Pricing Item -->

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="300">
            <div class="pricing-item">
              <h3>Partnership</h3>
              <h4><sup>$</sup>7,999<span> / month</span></h4>
              <ul>
                <li><i class="bi bi-check"></i> Unlimited tracking</li>
                <li><i class="bi bi-check"></i> Share Profit with us</li>
                <li><i class="bi bi-check"></i> Partnership management dashboard</li>
                <li><i class="bi bi-check"></i> Premium support</li>
              </ul>
              <a href="contact.html">Contact Support</a>
            </div>
          </div><!-- End Pricing Item -->

        </div>

      </div>
    </section><!-- End Pricing Section -->

    
