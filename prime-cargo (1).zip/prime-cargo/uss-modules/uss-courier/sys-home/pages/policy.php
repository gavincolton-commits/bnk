 <section class="sample-page">
  <div class="container" data-aos="fade-up">
	<p>
	  >>> WRITE YOUR OWN PRIVACY POLICY HERE <BR>
	  >>> LOCATION: <?php echo Core::url( __FILE__, true ); ?>
	</p>
  </div>
</section>