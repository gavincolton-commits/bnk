
    <!-- ======= Featured Services Section ======= -->
    <section id="featured-services" class="featured-services">
      <div class="container">

        <div class="row gy-4">

          <div class="col-lg-4 col-md-6 service-item d-flex" data-aos="fade-up">
            <div class="icon flex-shrink-0"><i class="fa-solid fa-cart-flatbed"></i></div>
            <div>
              <h4 class="title">Technology</h4>
              <p class="description">Our technology allows our customers the most efficient logistics solutions and makes it easier for our customers and carriers to work with us online at any time of the day.</p>
              
            </div>
          </div>
          <!-- End Service Item -->

          <div class="col-lg-4 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="100">
            <div class="icon flex-shrink-0"><i class="fa-solid fa-truck"></i></div>
            <div>
              <h4 class="title">Our People</h4>
              <p class="description">Quickway Logistics is not only asset-backed but our shareholders are the best the industry has to offer and provide many years of logistics experience. </p>
              
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-4 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="200">
            <div class="icon flex-shrink-0"><i class="fa-solid fa-truck-ramp-box"></i></div>
            <div>
              <h4 class="title">Accountability</h4>
              <p class="description">We will be safe, professional, and accountable in everything we do. We value honesty, integrity, and open communication for problem-solving and continuous improvement.</p>
              
            </div>
          </div><!-- End Service Item -->

        </div>

      </div>
    </section><!-- End Featured Services Section -->

    <!-- ======= Services Section ======= -->
    <section id="service" class="services pt-0">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <span>Our Services</span>
          <h2>Our Services</h2>

        </div>

        <div class="row gy-4">

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="card">
              <div class="card-img">
                <img src="%{dir.img}/storage-service.jpg" alt="" class="img-fluid">
              </div>
              <h3><a href="services.html" class="stretched-link">AIR FREIGHT</a></h3>
              <p>We offer individuals and companies end-to-end logistics service with guaranteed delivery of any size shipment. Exporting of Personal Effects, Household Goods, Commercial Products, and more.</p>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
            <div class="card">
              <div class="card-img">
                <img src="%{dir.img}/logistics-service.jpg" alt="" class="img-fluid">
              </div>
              <h3><a href="services.html" class="stretched-link">OCEAN FREIGHT</a></h3>
              <p>We ship from United States to various destinations in accross the world. We offer all types of containerized shipping, from less than container loads to 20′, 40′ and refrigerated containers.</p>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="300">
            <div class="card">
              <div class="card-img">
                <img src="%{dir.img}/cargo-service.jpg" alt="" class="img-fluid">
              </div>
              <h3><a href="services.html" class="stretched-link">PROCUREMENT</a></h3>
              <p>Does your company value saving money, time and improving its eficiency? This is where we come in. We can help source and procure just about anything in the US and ship straight to your door.</p>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="400">
            <div class="card">
              <div class="card-img">
                <img src="%{dir.img}/trucking-service.jpg" alt="" class="img-fluid">
              </div>
              <h3><a href="services.html" class="stretched-link">LOGISTICS</a></h3>
              <p>We can help move your vehicle from city to city,transport and coordinate your things anywhere in the world. If you’re shipping out of the country, or simply moving your cargo domestically, we can handle any cargo or commodity.</p>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="500">
            <div class="card">
              <div class="card-img">
                <img src="%{dir.img}/packaging-service.jpg" alt="" class="img-fluid">
              </div>
              <h3><a href="services.html" class="stretched-link">FREIGHT FORWARDING</a></h3>
              <p>If you wish to ship personal items of any kind, regardless of the weight, you've come to the right place. We provide both ocean freight & air freight, customs clearance, loading and trans-loading, & consolidation services. 
                </p>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="card">
              <div class="card-img">
                <img src="%{dir.img}/warehousing-service.jpg" alt="" class="img-fluid">
              </div>
              <h3><a href="services.html" class="stretched-link">WAREHOUSING</a></h3>
              <p>We have top notch security and loads of space. Store your stuff at our warehouse. Use our warehouse service as your distribution center. Our warehouses offers more than enough space for consolidation service at no extra charge,
              </p>
            </div>
          </div><!-- End Card Item -->

        </div>

      </div>
    </section><!-- End Services Section -->

    <!-- ======= Call To Action Section ======= -->
    <section id="call-to-action" class="call-to-action">
      <div class="container" data-aos="zoom-out">

        <div class="row justify-content-center">
          <div class="col-lg-8 text-center">
            <h3>Welcome To %{site.title}</h3>
            <p> We are a full-service Ocean freight forwarder licensed by the FMC operating as Ocean Transportation Intermediary ("OTI"). Our
Mission is to retain our leadership in providing affordable & efficient service.</p>
            <a class="cta-btn" href="contact.html">Visit Us Today</a>
          </div>
        </div>

      </div>
    </section><!-- End Call To Action Section -->

    <!-- ======= Features Section ======= -->
    <section id="features" class="features">
      <div class="container">

        <div class="row gy-4 align-items-center features-item" data-aos="fade-up">

          <div class="col-md-5">
            <img src="%{dir.img}/features-1.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7">
            <h3>SHIP WITH US.</h3>
            <p class="fst-italic">
              Why should you ship with us?
            </p>
            <ul>
              <li><i class="bi bi-check"></i> We are quite reliable.</li>
              <li><i class="bi bi-check"></i> Trustworthy - our word is our bond.</li>
              <li><i class="bi bi-check"></i> Expert in the business, in & out!</li>
              <li><i class="bi bi-check"></i> Very competitive price for high quality service</li>
              <li><i class="bi bi-check"></i> Fully licensed and insured!</li>
              <li><i class="bi bi-check"></i> You Will Always Get Outstanding Customer Service, we promise.</li>
            </ul>
          </div>
        </div><!-- Features Item -->

        <div class="row gy-4 align-items-center features-item" data-aos="fade-up">
          <div class="col-md-5 order-1 order-md-2">
            <img src="%{dir.img}/features-2.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 order-2 order-md-1">
            <h3>Roll On Roll Off (Ro-Ro) Shipping</h3>
            <p class="fst-italic">
              This is the simplest and cheapest method of shipping for vehicles. Vehicles are driven directly onto the RORO vessel and secured to the car decks. They are securely inside the vessel, wind-and-watertight.
            </p>
            <p>
              It is important to note that you cannot ship personal effects using this method, but spare tire and factory fitted accessories are allowed." Usually takes about 21 days from the date of vessel departure to any part of the world.
            </p>
          </div>
        </div><!-- Features Item -->

        <div class="row gy-4 align-items-center features-item" data-aos="fade-up">
          <div class="col-md-5">
            <img src="%{dir.img}/features-3.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7">
            <h3>How It Works</h3>
            <p></p>
            <ul>
              <li><i class="bi bi-check"></i><strong>Bring or Send Your Item(s)</strong> Drop off your item(s) in person or have it mailed to us using your in-house address you'll get when you sign up for a free account with us.</li>
              <li><i class="bi bi-check"></i> <strong>We Process Your Item(s)</strong> We confirm receipt, process payment, & package your item(s) accordingly & set ready for shipment.</li>
              <li><i class="bi bi-check"></i><strong>We Deliver to Your Destination</strong>We ship your item(s) and deliver to yourfinal destination. Air freight: 7-10 days, Ro-RO: 21 days, Container: 6-8 weeks.</li>
            </ul>
          </div>
        </div><!-- Features Item -->

        <div class="row gy-4 align-items-center features-item" data-aos="fade-up">
          <div class="col-md-5 order-1 order-md-2">
            <img src="%{dir.img}/features-4.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 order-2 order-md-1">
            <h3>Container Shipping</h3>
            <p class="fst-italic">
              Safe and secure inside your own container. All vehicles are securely blocked, braced and tied down ensuring absolute security during transportation.
            </p>
            <p>
              Generally your vehicle is loaded into a 20ft or 40ft steel container at a port or the nearest regional warehouse, then the container is later loaded onto the vessel.
              </p>
              <p>
              
              With this method, you can ship any personal effects inside the vehicle. Takes between 2 - 10 weeks to make it to to anypart of the world from the United States.
            </p>
          </div>
        </div><!-- Features Item -->

      </div>
    </section><!-- End Features Section -->

   
