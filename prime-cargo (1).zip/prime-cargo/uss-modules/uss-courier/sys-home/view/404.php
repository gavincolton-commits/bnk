<div class='py-5 px-3'>
	<div class='text-center py-5'>
				
		<img src='<?php echo Core::url( ASSETS_DIR . "/images/errors/error-404.webp" ); ?>' width='380px' class='img-fluid'>
		
		<h4 class='fw-light'>Sorry! The page you're looking for was not found </h4>
		
	</div>
</div>