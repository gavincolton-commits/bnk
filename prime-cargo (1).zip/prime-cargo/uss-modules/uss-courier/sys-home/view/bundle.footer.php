
	<script src="<?php echo Core::url( $this->assets_dir . "/vendor/purecounter/purecounter_vanilla.js" ); ?>"></script>
	<script src="<?php echo Core::url( $this->assets_dir . "/vendor/glightbox/js/glightbox.min.js" ); ?>"></script>
	<script src="<?php echo Core::url( $this->assets_dir . "/vendor/swiper/swiper-bundle.min.js" ); ?>"></script>
	<script src="<?php echo Core::url( $this->assets_dir . "/vendor/aos/aos.js" ); ?>"></script>
	<script src="<?php echo Core::url( $this->assets_dir . "/vendor/php-email-form/validate.js" ); ?>"></script>

	<!-- Template Main JS File -->
	<script src="<?php echo Core::url( $this->assets_dir . "/js/main.js" ); ?>"></script>
	
	<?php 
		call_user_func(function() {
			
			if( Uss::query(0) != 'tracker' || empty(Uss::tag('map.lat')) ) return;
	?>
	
	<script src = "<?php echo Core::url( $this->assets_dir . "/vendor/leafletjs/leaflet.js" ); ?>"></script>
	<script>
		
		// Creating map options
		var mapOptions = {
			center: [%{map.lat}, %{map.lng}],
			zoom: 10
		}
		
		// Creating a map object
		var map = new L.map('map', mapOptions);
		
		// Creating a Layer object
		var layer = new L.TileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png');
		
		// Adding layer to the map
		map.addLayer(layer);
		
		// Creating a marker
        var marker = L.marker([%{map.lat}, %{map.lng}]);
         
        // Adding marker to the map
        marker.addTo(map);
		
	</script>
	
	<?php }); ?>
