<?php

defined( 'COURIER_DIR' ) OR DIE;

//$profile = Uss::$global['menu']->get('profile')->get('profile');
//$profile->parentMenu->setAttr('href', $profile->getAttr('href'));
//$profile->parentMenu->remove('profile');

$dirs = array(
	'profile',
	'payment',
	'shipment'
);

foreach( $dirs as $directory ) require __DIR__ . "/{$directory}/index.php";

/**
 *
 */
require __DIR__ . "/landing.php";

