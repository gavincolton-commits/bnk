<?php

$profileFocus = UDASH_ROUTE . "/account/profile";

$profileMenu = Uss::$global['menu']->get('profile')->add('user-info', array(
	"label" => "information",
	"href" => Core::url( ROOT_DIR . "/{$profileFocus}" )
));

/**
 * Profile Info
 */
Uss::route( $profileFocus, function() use($profileMenu) {
	
	$profileMenu->setAttr( 'active', true );
	
	require __DIR__ . "/POST.php";
	
	Udash::view(function() {
		
		require __DIR__ . '/template.php';
		
	});
	
}, null);