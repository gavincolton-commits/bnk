<?php 

defined( 'ROOT_DIR' ) OR DIE;

new class {
	
	public function __construct() {
		
		if( !Uss::$global['user'] ) return;
		
		if( $_SERVER['REQUEST_METHOD'] == 'POST' ) $this->handlePOST( $_POST );
		
		$this->loadTemplate();
		
	}
	
	private function handlePOST( $data ) {
		
		$saved = Uss::$global['usermeta']->set( 'profile', $data, Uss::$global['user']['id'] );
		
		if( $saved ) {
			Uss::console('@alert', "<i class='bi bi-check-circle'></i> Your profile has been updated" );
		} else Uss::console("@alert", "<i class='bi bi-x-lg'></i> Your profile was not updated" );
		
	}
	
	private function loadTemplate() {
		$profile = Uss::$global['usermeta']->get('profile', Uss::$global['user']['id']);
		if( $profile ) {
			$profile['email'] = Uss::$global['user']['email'];
			foreach( $profile as $key => $value ) {
				Uss::tag("profile.{$key}", $value);
			}
		}
	}
	
};