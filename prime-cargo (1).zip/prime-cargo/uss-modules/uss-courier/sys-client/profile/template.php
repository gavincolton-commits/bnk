<div class='container-fluid'>

	<div class='row'>
		<div class='col-md-9 mx-auto'>
		
			<div class='card'>
				<div class='card-body p-4 p-sm-5'>
					
					<form method='POST'>
						
						<div class='row mb-3'>
							<div class='col-12 mb-2'>
								<label class='form-label'>Email</label>
								<input type='email' disabled class='form-control cursor-not-allowed' value='<?php echo Uss::$global['user']['email']; ?>'>
							</div>
						</div>
						
						<div class='row mb-3'>
							<div class='col-sm-6 mb-2'>
								<label class='form-label'>First Name</label>
								<input type='text' class='form-control' name='firstname' value='%{profile.firstname}' required>
							</div>
							<div class='col-sm-6'>
								<label class='form-label'>Last Name</label>
								<input type='text' class='form-control' name='lastname' value='%{profile.lastname}' required>
							</div>
						</div>
						
						<div class='row mb-3'>
							<div class='col-sm-4 mb-3'>
								<label class='form-label'>Country Code</label>
								<select type='text' class='form-control' name='country' value='%{profile.country}' required>
									<?php
										foreach( Udash::countries(null, true) as $country ):
									?>
									<option value='<?php echo $country['iso_2']; ?>'>
										<?php echo $country['name'] . ' ' . $country['dial_code']; ?>
									</option>
									<?php endforeach; ?>
								</select>
							</div>
							<div class='col-sm-8'>
								<label class='form-label'>Phone</label>
								<input type='number' class='form-control' name='phone' value='%{profile.phone}' required>
							</div>
						</div>
						
						<div class='row mb-3'>
							<div class='col-12 mb-3'>
								<label class='form-label'>Province</label>
								<input type='text' class='form-control' name='state' value='%{profile.state}' required>
							</div>
							<div class='col-12'>
								<label class='form-label'>Address</label>
								<textarea type='number' class='form-control' name='address' rows='6' required>%{profile.address}</textarea>
							</div>
						</div>
						
						<div class='row mb-3'>
							<button class='btn btn-success'>
								<i class='bi bi-save me-1'></i> Save Info
							</button>
						</div>
					
					</form>
					
				</div>
			</div>
			
		</div>
	</div>
	
</div>