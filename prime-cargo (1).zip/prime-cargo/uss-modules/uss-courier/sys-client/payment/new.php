<?php 

defined( 'COURIER_DIR' ) OR DIE;

$paynewFocus = $paymentFocus . "/new";

Uss::route( $paynewFocus . "/([a-zA-Z0-9\-]+)", function($match) {
	
	if( Uss::$global['user'] ) {
		
		$order = Udash::fetch_assoc( DB_TABLE_PREFIX . "_orders", $match[1], "order_no" );
		
		if( $order['sender_id'] != Uss::$global['user']['id'] ) $order = null;
		
		$res = require __DIR__ . '/POST.php';
		$res->currency = self::$currency;
	
	} else $order = $res = null;
	
	Udash::view(function() use($res) {
		
		if( !$res->order ) return Udash::empty_state("You probably do no have any shipment that matches the Track ID");
		
		if( !$res->showInvoice ) require_once __DIR__ . "/bills.php";
		
		else self::invoice( $res->order['order_no'] );
		
	});
	
}, null);