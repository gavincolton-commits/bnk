<?php 

$paymentFocus = self::$clientFocus . "/payment";

require __DIR__ . '/new.php';
require __DIR__ . '/history.php';