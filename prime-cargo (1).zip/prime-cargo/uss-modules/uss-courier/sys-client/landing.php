<?php 

defined( 'COURIER_DIR' ) OR DIE;

Events::addListener('udash:pages/index', function() {
	
	if( !Uss::$global['user'] ) return;
	
	$stats = self::stats( Uss::$global['user']['id'] );
	
	$keys = [
		'placements' => "bi bi-truck-flatbed", 
		'payments' => "bi bi-coin", 
		'received' => "bi bi-box"
	];
	
?>

	<div class='container-fluid'>
		
		<h2 class='fw-light'>Hi %{user.username}</h2>
		<p class='lead'>Welcome to your dashboard</p>
		
		<hr>
		
		<div class='row'>
			<?php 
				foreach( $keys as $key => $icon ): 
			?>
				<div class='col-sm-6 col-xl-4 mb-3'>
					<div class='card'>
						<div class='card-body'>
							<h1 class='display-6 text-capitalize'><?php echo $key; ?></h1>
							<hr>
							<h1 class='display-6'>
								<i class='<?php echo $icon; ?> me-2'></i>
								<?php echo $stats->{$key}; ?>
							</h1>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
	
<?php });