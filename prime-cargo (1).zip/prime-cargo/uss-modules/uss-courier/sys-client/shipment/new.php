<?php

defined( 'COURIER_DIR' ) OR DIE;

$shipnewFocus = $shipmentFocus . "/new";

$shipnewMenu = Uss::$global['menu']->add('shipnew', array(
	'label' => 'New Shipment',
	'icon' => '<i class="bi bi-send-plus"></i>',
	'href' => self::href( $shipnewFocus )
));

/**
 * Page
 */
Uss::route( $shipnewFocus, function() use($shipnewMenu, $shiplistFocus) {
	
	$shipnewMenu->setAttr('active', true);
	
	require __DIR__ . '/POST.php';
	
	Udash::view(function() {
		
		require __DIR__ . '/template-new.php';
		
	});
	
}, NULL);
