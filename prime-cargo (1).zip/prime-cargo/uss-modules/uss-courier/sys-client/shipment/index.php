<?php 

defined( 'COURIER_DIR' ) OR DIE;

$shipmentFocus = self::$clientFocus . "/shipment";

require __DIR__ . '/list.php';
require __DIR__ . '/new.php';

