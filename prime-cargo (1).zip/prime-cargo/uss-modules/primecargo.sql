-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 07, 2023 at 07:03 AM
-- Server version: 10.5.20-MariaDB-cll-lve-log
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scrixuez_courier`
--

-- --------------------------------------------------------

--
-- Table structure for table `uss_gateways`
--

CREATE TABLE `uss_gateways` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `abbr` varchar(10) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL COMMENT 'Bank,Crypto,3rd Party',
  `detail` text DEFAULT NULL COMMENT 'JSON',
  `period` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '-1 To Hide'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_gateways`
--

INSERT INTO `uss_gateways` (`id`, `name`, `abbr`, `icon`, `model`, `detail`, `period`, `status`) VALUES
(1, 'Bitcoin', 'BTC', 'images/gateway/2f7b5cb8ccc4dda9d03b4d9dfadfa532c4cda238.jpg', 'crypto', '{\"wallet address\":\"bc1qhj2v9gdlamu43m5xlan9evmpvmnmtxwn8e6ezd\"}', '2023-05-07 20:20:55', 1),
(2, 'Ethereum', 'ETH', 'images/gateway/b78dd4b866d1d8970ff34930f5422f2625207358.jpg', 'crypto', '{\"wallet address\":\"0xA3Fefc7Cd98C92A355B83D0D8aF8749F83cb024a\"}', '2023-05-07 20:24:32', 1);

-- --------------------------------------------------------

--
-- Table structure for table `uss_notifications`
--

CREATE TABLE `uss_notifications` (
  `id` int(11) NOT NULL,
  `origin` int(11) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL COMMENT 'TYPE: Comment, Reply, Module-Name...',
  `userid` int(11) NOT NULL,
  `period` timestamp NOT NULL DEFAULT current_timestamp(),
  `message` varchar(5000) DEFAULT NULL,
  `viewed` tinyint(4) NOT NULL DEFAULT 0,
  `redirect` varchar(255) DEFAULT NULL COMMENT 'URL',
  `image` varchar(255) DEFAULT NULL,
  `hidden` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_notifications`
--

INSERT INTO `uss_notifications` (`id`, `origin`, `model`, `userid`, `period`, `message`, `viewed`, `redirect`, `image`, `hidden`) VALUES
(1, 3, 'courier', 1, '2023-05-08 09:44:03', '**ucscode** sent a new shipment request on May 08th, May - 05:44 AM \n\n **Order ID**: 62iUO8mC', 0, '/aa-courier/admin/cargo/shipping/new/62iUO8mC', NULL, 1),
(2, NULL, 'courier', 1, '2023-05-08 09:48:08', 'A new payment request just came through for the shipment #t3sfK-HNHnXAWiCTDlFQ\n\nPlease confirm the payment and activate shipment.', 0, 'https://scriptstesters.website/aa-courier/admin/cargo/shipping/new/t3sfK-HNHnXAWiCTDlFQ', NULL, 1),
(3, NULL, 'courier', 1, '2023-05-08 09:51:43', 'A new payment request just came through for the shipment #t3sfK-HNHnXAWiCTDlFQ\n\nPlease confirm the payment and activate shipment.', 0, 'https://scriptstesters.website/aa-courier/admin/cargo/shipping/new/t3sfK-HNHnXAWiCTDlFQ', NULL, 1),
(4, 4, 'courier', 1, '2023-07-02 10:04:31', '**digitalwebplus52@gmail.com** sent a new shipment request on Jul 02nd, Jul - 06:04 AM \n\n **Order ID**: subFzjUA', 0, '/aa-courier/admin/cargo/shipping/new/subFzjUA', NULL, 1),
(5, NULL, 'courier', 1, '2023-07-02 11:32:40', 'A new payment request just came through for the shipment #BATdv3l4\n\nPlease confirm the payment and activate shipment.', 0, 'https://scriptstesters.website/aa-courier/admin/cargo/shipping/new/BATdv3l4', NULL, 1),
(6, 4, 'courier', 1, '2023-07-25 21:05:02', '**digitalwebplus52@gmail.com** sent a new shipment request on Jul 25th, Jul - 05:05 PM \n\n **Order ID**: TaC2EEkx', 0, '/aa-courier/admin/cargo/shipping/new/TaC2EEkx', NULL, 1),
(7, NULL, 'courier', 1, '2023-07-25 21:11:19', 'A new payment request just came through for the shipment #TaC2EEkx\n\nPlease confirm the payment and activate shipment.', 1, 'https://scriptstesters.website/aa-courier/admin/cargo/shipping/new/TaC2EEkx', NULL, 1),
(8, 4, 'courier', 1, '2023-07-28 12:20:49', '**digitalwebplus52@gmail.com** sent a new shipment request on Jul 28th, Jul - 08:20 AM \n\n **Order ID**: MGqIp7aQ', 1, '/aa-courier/admin/cargo/shipping/new/MGqIp7aQ', NULL, 1),
(9, 4, 'courier', 1, '2023-07-31 22:12:34', '**digitalwebplus52@gmail.com** sent a new shipment request on Jul 31st, Jul - 06:12 PM \n\n **Order ID**: p6V5m1Rt', 0, '/aa-courier/admin/cargo/shipping/new/p6V5m1Rt', NULL, 1),
(10, 1, 'courier', 4, '2023-07-31 22:15:29', 'Your package shipment has been approved.\n\nPlease proceed to payment or invoice statment', 0, '/aa-courier/dashboard/cargo/payment/new/p6V5m1Rt', NULL, 0),
(11, NULL, 'courier', 1, '2023-07-31 22:28:28', 'A new payment request just came through for the shipment #p6V5m1Rt\n\nPlease confirm the payment and activate shipment.', 1, 'https://scriptstesters.website/aa-courier/admin/cargo/shipping/new/p6V5m1Rt', NULL, 1),
(12, NULL, 'courier', 4, '2023-07-31 22:29:31', 'Your payment for order #p6V5m1Rt is approved\n\nThank you for choosing Prime Cargo', 0, 'https://scriptstesters.website/aa-courier/dashboard/cargo/payment/new/p6V5m1Rt', NULL, 0),
(13, 1, 'courier', 4, '2023-08-07 06:11:12', 'Your package shipment has been approved.\n\nPlease proceed to payment or invoice statment', 0, '/aa-courier/dashboard/cargo/payment/new/p6V5m1Rt', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `uss_offices`
--

CREATE TABLE `uss_offices` (
  `id` int(11) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `address` varchar(300) NOT NULL,
  `state` varchar(255) NOT NULL,
  `country` varchar(3) DEFAULT NULL,
  `email` varchar(1000) DEFAULT NULL COMMENT 'comma separated',
  `phone` varchar(1000) DEFAULT NULL COMMENT 'comma separated',
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT 'enabled/disabled',
  `period` timestamp NOT NULL DEFAULT current_timestamp(),
  `creator` int(11) NOT NULL COMMENT 'user[id]',
  `_default` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_offices`
--

INSERT INTO `uss_offices` (`id`, `branch`, `address`, `state`, `country`, `email`, `phone`, `status`, `period`, `creator`, `_default`) VALUES
(1, 'New York Office', 'this is the New York address here', 'New York', 'US', 'info@yourdomain.com', '1234567890', 1, '2023-05-07 20:04:36', 1, 1),
(2, 'London Office', 'The London address will be here', 'London', 'GB', 'info@yourdomain.com', '1234567890', 1, '2023-05-07 20:10:17', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `uss_options`
--

CREATE TABLE `uss_options` (
  `id` int(11) NOT NULL,
  `_ref` int(11) DEFAULT NULL,
  `_key` varchar(255) NOT NULL,
  `_value` text DEFAULT NULL,
  `epoch` bigint(20) NOT NULL DEFAULT unix_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_options`
--

INSERT INTO `uss_options` (`id`, `_ref`, `_key`, `_value`, `epoch`) VALUES
(1, NULL, 'user:disable-signup', '\"0\"', 1683019260),
(2, NULL, 'user:collect-username', '\"0\"', 1683019260),
(3, NULL, 'user:confirm-email', '\"0\"', 1683019260),
(4, NULL, 'user:lock-email', '\"0\"', 1683019260),
(5, NULL, 'user:reconfirm-email', '\"1\"', 1683019260),
(6, NULL, 'user:default-role', '\"member\"', 1683019260),
(7, NULL, 'user:affiliation', '\"0\"', 1683019260),
(8, NULL, 'user:auto-trash-unverified-after-day', '\"7\"', 1683019260),
(9, NULL, 'email:admin', '\"info@scriptstesters.website\"', 1683019260),
(10, NULL, 'smtp:state', '\"default\"', 1683019260),
(11, NULL, 'site:title', '\"Prime Cargo\"', 1683458311),
(12, NULL, 'site:tagline', '\"A reliable courier and logistics management system. Powered by <a href = \\\"http:\\/\\/digitalwebplus.com\\\" target = \\\"_blank\\\"> DigitalWeb Plus <\\/a>\"', 1683458311),
(13, NULL, 'site:description', '\"Our experienced professionals are equipped to handle your complete transportation needs.\\r\\n\\r\\nLet Prime Cargo bring simplicity to your logistics by leveraging our assets and preferred carrier network. \"', 1683458311),
(14, NULL, 'email:from', '\"\"', 1683491737),
(15, NULL, 'site:currency', '\"$\"', 1690199284),
(16, NULL, 'site:icon', '\"uss-dashboard-main\\/ud-assets\\/images\\/general\\/2eda18c1e8ea574468ba506f9621a62b50d5c282.png\"', 1690200086);

-- --------------------------------------------------------

--
-- Table structure for table `uss_orders`
--

CREATE TABLE `uss_orders` (
  `id` int(11) NOT NULL,
  `name` tinytext DEFAULT NULL,
  `order_no` varchar(20) NOT NULL,
  `office_id` int(11) NOT NULL,
  `status` varchar(100) DEFAULT NULL,
  `period` timestamp NOT NULL DEFAULT current_timestamp(),
  `pickup_date` varchar(20) DEFAULT NULL,
  `depature_date` varchar(20) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `expected_delivery_date` varchar(20) DEFAULT NULL,
  `order_comment` text DEFAULT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) DEFAULT NULL,
  `price` float DEFAULT 0,
  `approval` varchar(20) DEFAULT 'pending'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_orders`
--

INSERT INTO `uss_orders` (`id`, `name`, `order_no`, `office_id`, `status`, `period`, `pickup_date`, `depature_date`, `staff_id`, `expected_delivery_date`, `order_comment`, `sender_id`, `receiver_id`, `price`, `approval`) VALUES
(9, 'Bag of Salt', 'p6V5m1Rt', 2, 'queue', '2023-07-31 22:12:34', '2023-07-31T23:17', '2023-07-21T11:15', 3, '2023-07-31T11:16', 'In good condition', 4, NULL, 500, 'approved'),
(5, 'Try Again', 'BATdv3l4', 2, 'in transit', '2023-07-02 09:19:19', '2023-07-02T10:16', '2023-07-02T22:18', 3, '2023-07-02T22:14', 'Good Condition', 4, NULL, 50, 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `uss_order_meta`
--

CREATE TABLE `uss_order_meta` (
  `id` int(11) NOT NULL,
  `_ref` int(11) NOT NULL,
  `_key` varchar(255) NOT NULL,
  `_value` text DEFAULT NULL,
  `epoch` bigint(20) NOT NULL DEFAULT unix_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_order_meta`
--

INSERT INTO `uss_order_meta` (`id`, `_ref`, `_key`, `_value`, `epoch`) VALUES
(1, 1, 'sender_email', '\"digitalwebplus52@gmail.com\"', 1683492947),
(2, 1, 'sender_info', '{\"name\":\"Paul Smith\",\"phone\":\"1234567890\",\"address\":\"paul smith\'s address will be here\",\"state\":\"Lagos\",\"country\":\"NG\"}', 1683492947),
(3, 1, 'receiver_email', '\"demotest@trial.com\"', 1683492947),
(4, 1, 'receiver_info', '{\"name\":\"Tom King\",\"phone\":\"0987654321\",\"address\":\"Tom King\'s address will be here\",\"state\":\"New York\",\"country\":\"US\"}', 1683492947),
(5, 2, 'sender_email', '\"Uche23mail@gmail.com\"', 1683538454),
(6, 2, 'sender_info', '{\"name\":\"Elizabeth Ogbu\",\"phone\":\"08125858560\",\"address\":\"293 agege motor road\",\"state\":\"Lagos\",\"country\":\"NG\"}', 1683538454),
(7, 2, 'receiver_email', '\"lizzyogb1@gmail.com\"', 1683538454),
(8, 2, 'receiver_info', '{\"name\":\"Uchenna Ajah\",\"phone\":\"08125858560\",\"address\":\"293 Agege Motor Road\",\"state\":\"Lagos\",\"country\":\"NG\"}', 1683538454),
(9, 3, 'sender_info', '{\"name\":\"Uchenna Ajah\",\"country\":\"NG\",\"phone\":\"9122065408\",\"state\":\"lagos\",\"address\":\"A place to be\\r\\n\"}', 1683539043),
(10, 3, 'receiver_email', '\"spacecaft@gmail.com\"', 1683539043),
(11, 3, 'receiver_info', '{\"name\":\"patience Ogbu\",\"country\":\"NG\",\"phone\":\"08125858560\",\"state\":\"Lagos\",\"address\":\"8 Folawewo Street\"}', 1683539043),
(12, 3, 'sender_email', '\"uche23mail@gmail.com\"', 1683539043),
(13, 4, 'sender_email', '\"digitalwebplus52@gmail.com\"', 1688288936),
(14, 4, 'sender_info', '{\"name\":\"Ebuka\",\"phone\":\"000765434567\",\"address\":\"Lagos\",\"state\":\"Lagos\",\"country\":\"NG\"}', 1688288936),
(15, 4, 'receiver_email', '\"\"', 1688288936),
(16, 4, 'receiver_info', '{\"name\":\"workz101@workz@gmail.com\",\"phone\":\"0007656780\",\"address\":\"Abuja\",\"state\":\"FCT\",\"country\":\"NG\"}', 1688288936),
(17, 5, 'sender_email', '\"digitalwebplus52@gmail.com\"', 1688289559),
(18, 5, 'sender_info', '{\"name\":\"Alvim\",\"phone\":\"9876543\",\"address\":\"bvyug\",\"state\":\"ugu\",\"country\":\"AZ\"}', 1688289559),
(19, 5, 'receiver_email', '\"workz101workz@gmail.com\"', 1688289559),
(20, 5, 'receiver_info', '{\"name\":\"retest\",\"phone\":\"098765434\",\"address\":\"dyjguihno\",\"state\":\"kugh\",\"country\":\"AW\"}', 1688289559),
(21, 6, 'sender_info', '{\"name\":\"Paul User\",\"country\":\"NG\",\"phone\":\"1234567890\",\"state\":\"Abuja\",\"address\":\"Abuja, Nigeria\"}', 1688292271),
(22, 6, 'receiver_email', '\"workz101workz@gmail.com\"', 1688292271),
(23, 6, 'receiver_info', '{\"name\":\"James Jhon\",\"country\":\"AQ\",\"phone\":\"112345433333\",\"state\":\"dgeth\",\"address\":\"h ghrt addresdffg fb\"}', 1688292271),
(24, 6, 'sender_email', '\"digitalwebplus52@gmail.com\"', 1688292271),
(25, 7, 'sender_info', '{\"name\":\"Paul User\",\"phone\":\"1234567890\",\"address\":\"Abuja, Nigeria\",\"state\":\"Abuja\",\"country\":\"NG\"}', 1690319102),
(26, 7, 'receiver_email', '\"ikeji2ebuka@gmail.com\"', 1690319102),
(27, 7, 'receiver_info', '{\"name\":\"Paul Smith\",\"phone\":\"098765432\",\"address\":\"wrge fht\",\"state\":\"dfr\",\"country\":\"FO\"}', 1690319102),
(28, 7, 'sender_email', '\"digitalwebplus52@gmail.com\"', 1690319102),
(29, 8, 'sender_info', '{\"name\":\"Paul User\",\"country\":\"NG\",\"phone\":\"1234567890\",\"state\":\"Abuja\",\"address\":\"Abuja, Nigeria\"}', 1690546849),
(30, 8, 'receiver_email', '\"trial33@gmail.com\"', 1690546849),
(31, 8, 'receiver_info', '{\"name\":\"Sam Pat\",\"country\":\"DZ\",\"phone\":\"1234567890\",\"state\":\"Algeria state\",\"address\":\"this is the receivers address\"}', 1690546849),
(32, 8, 'sender_email', '\"digitalwebplus52@gmail.com\"', 1690546849),
(33, 9, 'sender_info', '{\"name\":\"Paul User\",\"phone\":\"1234567890\",\"address\":\"Abuja, Nigeria\",\"state\":\"Abuja\",\"country\":\"NG\"}', 1690841554),
(34, 9, 'receiver_email', '\"trial33@gmail.com\"', 1690841554),
(35, 9, 'receiver_info', '{\"name\":\"Pat Sam\",\"phone\":\"1234567889\",\"address\":\"Lagos Nigeria.\",\"state\":\"Algeria state\",\"country\":\"AD\"}', 1690841554),
(36, 9, 'sender_email', '\"digitalwebplus52@gmail.com\"', 1690841554),
(37, 9, 'delivery_info', '{\"origin\":{\"address\":\"Balane road\",\"city\":\"Ikeja\",\"country\":\"NG\"},\"destination\":{\"address\":\"Ring road\",\"city\":\"Benin\",\"country\":\"NG\"}}', 1691388672);

-- --------------------------------------------------------

--
-- Table structure for table `uss_packages`
--

CREATE TABLE `uss_packages` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `item_no` varchar(10) NOT NULL,
  `name` varchar(1000) DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `var_id` int(11) DEFAULT NULL,
  `image` varchar(1000) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_packages`
--

INSERT INTO `uss_packages` (`id`, `order_id`, `item_no`, `name`, `weight`, `quantity`, `var_id`, `image`) VALUES
(2, 5, 'puCK9YEo', 'Cargo mail', 12, 33, 3, 'uss-courier/sys-admin/shipments/package/images/1689928080-20936e34b1fa5a78c26d06e8dc8b9f1b193ef6ac.jpg'),
(3, 5, 'StKBJIXf', 'Record Boss', 33, 1, 3, 'uss-courier/sys-admin/shipments/package/images/1689928189-1580ad2144bb7db1fb21c6cd61bb11fa8f9939b4.png'),
(4, 9, 'swB5OxLm', 'Salt', 35, 3, 2, 'uss-courier/sys-admin/shipments/package/images/1690841841-bb47aadb83aba37b1f50e8b5c976e17f70b2562d.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `uss_payments`
--

CREATE TABLE `uss_payments` (
  `id` int(11) NOT NULL,
  `invoice_key` varchar(255) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `amount` float NOT NULL DEFAULT 0,
  `screenshot` varchar(1000) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `method_id` int(11) DEFAULT NULL,
  `method_detail` text DEFAULT NULL,
  `period` timestamp NOT NULL DEFAULT current_timestamp(),
  `payment_ref` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_payments`
--

INSERT INTO `uss_payments` (`id`, `invoice_key`, `order_id`, `amount`, `screenshot`, `status`, `method_id`, `method_detail`, `period`, `payment_ref`) VALUES
(4, 'eD9FOJWa', 7, 500, NULL, 'approved', 1, '{\"wallet address\":\"bc1qhj2v9gdlamu43m5xlan9evmpvmnmtxwn8e6ezd\"}', '2023-07-25 21:11:19', 'bntyjuyky8ul'),
(5, 'p8J5sB03', 9, 500, 'uss-courier/sys-client/payment/screenshots/4db4e44adda148110e17747c4391ff27e3bf7ece1.jpg', 'approved', 1, '{\"wallet address\":\"bc1qhj2v9gdlamu43m5xlan9evmpvmnmtxwn8e6ezd\"}', '2023-07-31 22:28:28', 'wrweyerur6i7io6'),
(3, 'Dsorm648', 5, 50, NULL, 'approved', 1, '{\"wallet address\":\"bc1qhj2v9gdlamu43m5xlan9evmpvmnmtxwn8e6ezd\"}', '2023-07-02 11:32:40', 'frgetjhjyjyt');

-- --------------------------------------------------------

--
-- Table structure for table `uss_shipments`
--

CREATE TABLE `uss_shipments` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `country` varchar(3) NOT NULL,
  `state` varchar(255) NOT NULL,
  `local_area` varchar(1000) DEFAULT NULL,
  `longitude` varchar(20) DEFAULT NULL,
  `latitude` varchar(20) DEFAULT NULL,
  `period` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_shipments`
--

INSERT INTO `uss_shipments` (`id`, `order_id`, `country`, `state`, `local_area`, `longitude`, `latitude`, `period`) VALUES
(1, 2, 'NG', 'Lagos', '293 agege motor road', '50.4', '32.5', '2023-05-08 09:38:32'),
(4, 5, 'NG', 'Lagos', 'Fagbm Street, Abule', '3.388400', '6.451140', '2023-07-21 08:24:59'),
(3, 6, 'NG', 'Lagos', 'Unknown', '3.406448', '6.465422', '2023-07-21 06:24:20'),
(5, 9, 'NG', 'Abuja', 'Kubwa', '7.321965', '9.153849', '2023-07-31 22:18:51'),
(6, 9, 'NG', 'Lagos', 'Ikeja', '3.351486', '6.601838', '2023-07-31 22:22:05'),
(7, 9, 'NG', 'Edo', 'Ring Road', '', '', '2023-08-07 06:14:12');

-- --------------------------------------------------------

--
-- Table structure for table `uss_staffs`
--

CREATE TABLE `uss_staffs` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `staff_key` varchar(20) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT 'active/inactive',
  `period` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `uss_usermeta`
--

CREATE TABLE `uss_usermeta` (
  `id` int(11) NOT NULL,
  `_ref` int(11) NOT NULL,
  `_key` varchar(255) NOT NULL,
  `_value` text DEFAULT NULL,
  `epoch` bigint(20) NOT NULL DEFAULT unix_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_usermeta`
--

INSERT INTO `uss_usermeta` (`id`, `_ref`, `_key`, `_value`, `epoch`) VALUES
(1, 1, 'roles', '[\"member\",\"super-admin\"]', 1683031728),
(2, 2, 'roles', '[\"member\"]', 1683489562),
(3, 3, 'roles', '[\"member\",\"staff\",\"administrator\"]', 1683537980),
(4, 3, 'profile', '{\"firstname\":\"Uchenna\",\"lastname\":\"Ajah\",\"country\":\"NG\",\"phone\":\"9122065408\",\"state\":\"lagos\",\"address\":\"A place to be\\r\\n\"}', 1683538871),
(5, 4, 'roles', '[\"member\"]', 1688287450),
(6, 4, 'profile', '{\"firstname\":\"Paul\",\"lastname\":\"User\",\"country\":\"NG\",\"phone\":\"1234567890\",\"state\":\"Abuja\",\"address\":\"Abuja, Nigeria\"}', 1688287550);

-- --------------------------------------------------------

--
-- Table structure for table `uss_users`
--

CREATE TABLE `uss_users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(25) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `register_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `usercode` varchar(12) NOT NULL,
  `last_seen` timestamp NOT NULL DEFAULT current_timestamp(),
  `parent` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_users`
--

INSERT INTO `uss_users` (`id`, `email`, `username`, `password`, `register_time`, `usercode`, `last_seen`, `parent`) VALUES
(1, 'admin@yourdomain.com', NULL, '$2y$10$CY8qUODzNsnjSWFxaX0KnOewcEsC0pQluTA5NEovO5Wf1puA0MswG', '2023-05-02 12:48:48', '36EXgU', '2023-05-02 12:48:48', NULL),
(4, 'digitalwebplus52@gmail.com', NULL, '$2y$10$gtztAmcqTcnwrnQHHuN/LO2MZ/zb5/UoRsV9IRX.zbfd5FctRtbwi', '2023-07-02 08:44:10', 'CwPreHR', '2023-07-02 08:44:10', NULL),
(3, 'testaccountant111@gmail.com', 'accountant', '$2y$10$3UqxGmw.zIcXUq14oR/qh.UrHV7L4Gc35p0r.MdexJZV08h/VELIW', '2023-05-07 19:59:22', 'ucscode', '2023-05-07 19:59:22', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `uss_variants`
--

CREATE TABLE `uss_variants` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL COMMENT 'Package Group/Category'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uss_variants`
--

INSERT INTO `uss_variants` (`id`, `name`) VALUES
(1, 'Gadget'),
(2, 'Cargo'),
(3, 'Parcel');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `uss_gateways`
--
ALTER TABLE `uss_gateways`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uss_notifications`
--
ALTER TABLE `uss_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `uss_offices`
--
ALTER TABLE `uss_offices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uss_options`
--
ALTER TABLE `uss_options`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uss_orders`
--
ALTER TABLE `uss_orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_no` (`order_no`);

--
-- Indexes for table `uss_order_meta`
--
ALTER TABLE `uss_order_meta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uss_order_id` (`_ref`);

--
-- Indexes for table `uss_packages`
--
ALTER TABLE `uss_packages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `item_no` (`item_no`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `uss_payments`
--
ALTER TABLE `uss_payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `invoice_key` (`invoice_key`),
  ADD UNIQUE KEY `payment_ref` (`payment_ref`);

--
-- Indexes for table `uss_shipments`
--
ALTER TABLE `uss_shipments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `uss_staffs`
--
ALTER TABLE `uss_staffs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `staff_key` (`staff_key`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `uss_usermeta`
--
ALTER TABLE `uss_usermeta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uss_users` (`_ref`);

--
-- Indexes for table `uss_users`
--
ALTER TABLE `uss_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `usercode` (`usercode`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `parent` (`parent`);

--
-- Indexes for table `uss_variants`
--
ALTER TABLE `uss_variants`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `uss_gateways`
--
ALTER TABLE `uss_gateways`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `uss_notifications`
--
ALTER TABLE `uss_notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `uss_offices`
--
ALTER TABLE `uss_offices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `uss_options`
--
ALTER TABLE `uss_options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `uss_orders`
--
ALTER TABLE `uss_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `uss_order_meta`
--
ALTER TABLE `uss_order_meta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `uss_packages`
--
ALTER TABLE `uss_packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `uss_payments`
--
ALTER TABLE `uss_payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `uss_shipments`
--
ALTER TABLE `uss_shipments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `uss_staffs`
--
ALTER TABLE `uss_staffs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `uss_usermeta`
--
ALTER TABLE `uss_usermeta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `uss_users`
--
ALTER TABLE `uss_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `uss_variants`
--
ALTER TABLE `uss_variants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
