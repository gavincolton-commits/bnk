<?php

/**
 * HEAD Elements
 * This file container all default tags that should be within the `<head></head>` section
 */

defined('UDASH_DIR') or die;

?>	<link rel="stylesheet" href="<?php echo Core::url(Udash::ASSETS_DIR . "/css/default.css"); ?>" />
